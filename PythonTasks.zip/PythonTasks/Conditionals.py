a = 4
b = 4
boo = False
def sum(x,y,boo):
  istrue = boo
  if istrue == True:
    c = y+x
    print(c)
  if istrue == False:
    c = y*x
    print(c)
sum(a,b,boo)