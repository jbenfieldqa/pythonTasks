a = 4
b = 0
boo = False
def sum(x,y,boo):
  istrue = boo
  if istrue == True:
    c = y+x
    print(c)
  if istrue == False:
    c = y*x
    print(c)
  if a==0 or b==0:
    if a==0:
      print(a)
    if b==0:
      print(b)
sum(a,b,boo)