a = 4
b = 4
list =[1,2,3,4,5,6,7,8,9,10]
boo = True
def sum(x,y,boo):
  i = 0
  while (i < 10):
    istrue = boo
    if a==0 or b==0:
      if a==0:
        print(a)
        break
      if b==0:
        print(b)
        break
    i = i + 1
    if istrue == True:
      c = y+x
      print(c)
    if istrue == False:
      c = y*x
      print(c)
sum(list[1],list[2],boo)