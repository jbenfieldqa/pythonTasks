a = 4
b = 5
def sum(x,y):
  c = y+x
  print(c)
sum(a,b)