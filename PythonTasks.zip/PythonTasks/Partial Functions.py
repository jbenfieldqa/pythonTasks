from functools import partial

def muilt(x, y):
  return x * y

p_muiltDouble = partial(muilt, 2)
P_muiltTriple = partial(muilt, 3)

print(p_muiltDouble(3))
print(P_muiltTriple(3))

