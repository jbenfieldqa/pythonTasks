a = 4
b = 4

boo = False
def sum(x,y,boo):
  i = 0
  while (i < 10):
    istrue = boo
    if a==0 or b==0:
      if a==0:
        print(a)
        break
      if b==0:
        print(b)
        break
    i = i + 1
    if istrue == True:
      c = y+x
      print(c)
    if istrue == False:
      c = y*x
      print(c)

sum(a,b,boo)