listNum =[1]
newList =[]
def printlist(listN):
  i = 0
  for num in listN:
    i = num
    listNum.append(num+1)
    print(num)
    if listNum[i] > 10:
      break
def muiltby10(listN):
  for num in listN:
    x = num*10
    print(x)
printlist(listNum)
muiltby10(listNum)