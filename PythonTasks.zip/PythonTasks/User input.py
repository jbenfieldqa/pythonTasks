listNum =[1]
newList =[]
listSize = 1
def defListSize():
  ls = input("Input List Size")
  listS = ls
  return ls
def printlist(listN, listS):
  i = 0
  ls = listS
  for num in listN:
    i = num
    listNum.append(num+1)
    print(num)
    if listNum[i] > int(ls):
      break
def muiltby10(listN):
  for num in listN:
    x = num*10
    print(x)
    
listSize = defListSize()
print(listSize)

printlist(listNum,listSize)
muiltby10(listNum)