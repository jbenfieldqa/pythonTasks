x = 0
y = 0

def BlackJack(x,y):
  blackJack = 0
  if  x < 0 and y < 0:
    return 0
  valueX = 21 - x
  valueY = 21 - y
  
  if x > 21 and y > 21:
    return 0
  elif valueX > valueY:
    return y
  elif valueX < valueY:
    return x
    
print(int(BlackJack(18,20)))
print(int(BlackJack(22,22)))
print(int(BlackJack(19,17)))
  
    
  
  