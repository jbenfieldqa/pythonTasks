a = "hello world"
def printText(b):
  print(b) 
printText(a)